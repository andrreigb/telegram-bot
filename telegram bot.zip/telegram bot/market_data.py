import yfinance as yf
import pandas as pd

def get_xauusd_data(period="60d", interval="1h"):
    """
    Descarcă date XAUUSD.
    interval: 1m, 5m, 15m, 30m, 1h, 1d
    """
    ticker = yf.Ticker("GC=F")  # Gold Futures (XAUUSD proxy)
    df = ticker.history(period=period, interval=interval)
    
    if df.empty:
        print("Nu s-au putut descărca date.")
        return None
    
    df = df.reset_index()
    df = df.rename(columns={
        "Datetime": "Date",
        "Open": "Open",
        "High": "High",
        "Low": "Low",
        "Close": "Close",
        "Volume": "Volume"
    })
    
    return df[["Date", "Open", "High", "Low", "Close", "Volume"]]

if __name__ == "__main__":
    df = get_xauusd_data()
    if df is not None:
        print(f"Date descărcate: {len(df)} bare")
        print(df.tail())