import pandas as pd
import numpy as np

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Adaugă indicatori tehnici de bază."""
    df = df.copy()
    
    # Moving Averages
    df["SMA_20"] = df["Close"].rolling(20).mean()
    df["SMA_50"] = df["Close"].rolling(50).mean()
    df["EMA_12"] = df["Close"].ewm(span=12, adjust=False).mean()
    df["EMA_26"] = df["Close"].ewm(span=26, adjust=False).mean()
    
    # RSI
    delta = df["Close"].diff()
    gain = delta.where(delta > 0, 0).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
    rs = gain / loss
    df["RSI"] = 100 - (100 / (1 + rs))
    
    # MACD
    df["MACD"] = df["EMA_12"] - df["EMA_26"]
    df["MACD_Signal"] = df["MACD"].ewm(span=9, adjust=False).mean()
    df["MACD_Hist"] = df["MACD"] - df["MACD_Signal"]
    
    # ATR (volatilitate)
    high_low = df["High"] - df["Low"]
    high_close = (df["High"] - df["Close"].shift()).abs()
    low_close = (df["Low"] - df["Close"].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df["ATR"] = tr.rolling(14).mean()
    
    return df

def detect_trend(df: pd.DataFrame) -> str:
    """Detectează trendul simplu pe baza mediilor."""
    if len(df) < 50:
        return "INSUFFICIENT_DATA"
    
    last = df.iloc[-1]
    if last["SMA_20"] > last["SMA_50"] and last["Close"] > last["SMA_20"]:
        return "BULLISH"
    elif last["SMA_20"] < last["SMA_50"] and last["Close"] < last["SMA_20"]:
        return "BEARISH"
    else:
        return "SIDEWAYS"

if __name__ == "__main__":
    from market_data import get_xauusd_data
    
    df = get_xauusd_data()
    if df is not None:
        df = add_indicators(df)
        trend = detect_trend(df)
        print(f"Trend detectat: {trend}")
        print(df[["Date", "Close", "SMA_20", "SMA_50", "RSI"]].tail())