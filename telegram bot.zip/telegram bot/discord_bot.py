import discord
from discord.ext import commands
from config import Config

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

CHANNEL_ID = 1569402560287080480  # ID-ul canalului tău

async def send_log(message: str):
    """Trimite un mesaj de log pe canalul Discord."""
    if not Config.DISCORD_BOT_TOKEN:
        return
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        try:
            await channel.send(f"```{message}```")
        except Exception as e:
            print(f"Eroare Discord: {e}")

@bot.event
async def on_ready():
    print(f"Discord bot conectat ca {bot.user}")
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        await channel.send("```XAUUSD AI Assistant - Discord logging activ```")

def run_discord():
    if Config.DISCORD_BOT_TOKEN:
        bot.run(Config.DISCORD_BOT_TOKEN)
    else:
        print("Lipsește DISCORD_BOT_TOKEN în .env")

if __name__ == "__main__":
    run_discord()