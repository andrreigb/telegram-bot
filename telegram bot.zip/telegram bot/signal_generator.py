import pandas as pd
from market_data import get_xauusd_data
from indicators import add_indicators, detect_trend

def generate_signal(df: pd.DataFrame) -> dict:
    if len(df) < 50:
        return {"status": "WAIT", "reason": "Date insuficiente"}
    
    df = add_indicators(df)
    trend = detect_trend(df)
    last = df.iloc[-1]
    prev = df.iloc[-2]
    
    signal = {
        "symbol": "XAUUSD",
        "direction": "WAIT",
        "entry": round(last["Close"], 2),
        "stop_loss": None,
        "take_profit": None,
        "risk_reward": None,
        "timeframe": "H1",
        "strategy": "Multi-Strategy",
        "confidence": 0,
        "reasoning": "",
        "status": "WAITING"
    }
    
    reasons = []
    score = 0
    
    # 1. Trend Following
    if trend == "BULLISH":
        score += 25
        reasons.append("Trend bullish")
    elif trend == "BEARISH":
        score -= 25
        reasons.append("Trend bearish")
    
    # 2. RSI
    if 40 < last["RSI"] < 65 and trend == "BULLISH":
        score += 20
        reasons.append(f"RSI favorabil ({last['RSI']:.1f})")
    elif 35 < last["RSI"] < 60 and trend == "BEARISH":
        score -= 20
        reasons.append(f"RSI favorabil ({last['RSI']:.1f})")
    
    # 3. MACD Crossover
    if last["MACD"] > last["MACD_Signal"] and prev["MACD"] <= prev["MACD_Signal"]:
        score += 20
        reasons.append("MACD bullish crossover")
    elif last["MACD"] < last["MACD_Signal"] and prev["MACD"] >= prev["MACD_Signal"]:
        score -= 20
        reasons.append("MACD bearish crossover")
    
    # 4. Price vs SMA
    if last["Close"] > last["SMA_20"] > last["SMA_50"]:
        score += 15
        reasons.append("Preț peste mediile mobile")
    elif last["Close"] < last["SMA_20"] < last["SMA_50"]:
        score -= 15
        reasons.append("Preț sub mediile mobile")
    
    # Decizie finală
    if score >= 40:
        signal["direction"] = "BUY"
        signal["stop_loss"] = round(last["Close"] - last["ATR"] * 1.5, 2)
        signal["take_profit"] = round(last["Close"] + last["ATR"] * 3, 2)
        signal["confidence"] = min(90, 50 + score)
        signal["status"] = "ACTIVE"
    elif score <= -40:
        signal["direction"] = "SELL"
        signal["stop_loss"] = round(last["Close"] + last["ATR"] * 1.5, 2)
        signal["take_profit"] = round(last["Close"] - last["ATR"] * 3, 2)
        signal["confidence"] = min(90, 50 + abs(score))
        signal["status"] = "ACTIVE"
    
    if signal["stop_loss"] and signal["take_profit"]:
        risk = abs(signal["entry"] - signal["stop_loss"])
        reward = abs(signal["take_profit"] - signal["entry"])
        signal["risk_reward"] = round(reward / risk, 2) if risk > 0 else 0
    
    signal["reasoning"] = " | ".join(reasons) if reasons else "Condiții insuficiente"
    return signal