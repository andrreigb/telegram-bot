import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime
from config import Config

def connect_mt5():
    """Se conectează la MetaTrader 5."""
    mt5.shutdown()  # închide orice conexiune veche
    
    ok = mt5.initialize(
        path=Config.MT5_PATH,
        login=Config.MT5_LOGIN,
        password=Config.MT5_PASSWORD,
        server=Config.MT5_SERVER,
        timeout=30000
    )
    
    if not ok:
        print("Eroare la conectare:", mt5.last_error())
        return False
    
    print("Conectat cu succes la MT5!")
    account = mt5.account_info()
    if account:
        print(f"Cont: {account.login} | Balanta: {account.balance} {account.currency}")
    return True

def get_xauusd_data(timeframe=mt5.TIMEFRAME_H1, bars=500):
    """Descarcă date XAUUSD."""
    rates = mt5.copy_rates_from_pos("XAUUSD", timeframe, 0, bars)
    
    if rates is None or len(rates) == 0:
        print("Nu s-au putut descărca date:", mt5.last_error())
        return None
    
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    df = df.rename(columns={
        'time': 'Date',
        'open': 'Open',
        'high': 'High',
        'low': 'Low',
        'close': 'Close',
        'tick_volume': 'Volume'
    })
    
    return df

def shutdown():
    mt5.shutdown()
    print("Conexiune MT5 închisă.")

# Test rapid
if __name__ == "__main__":
    if connect_mt5():
        df = get_xauusd_data()
        if df is not None:
            print(f"\nDate descărcate: {len(df)} bare")
            print(df.tail())
        shutdown()