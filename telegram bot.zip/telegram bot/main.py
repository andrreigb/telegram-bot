from config import Config

def main():
    print("=== XAUUSD AI Trading Assistant ===")
    print(f"Symbol: {Config.SYMBOL}")
    print(f"MT5 Login: {Config.MT5_LOGIN}")
    print(f"Server: {Config.MT5_SERVER}")
    print("Configurare încărcată cu succes.")

if __name__ == "__main__":
    main()