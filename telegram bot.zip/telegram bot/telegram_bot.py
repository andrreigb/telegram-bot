import logging
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from config import Config
from signal_generator import generate_signal
from market_data import get_xauusd_data
from indicators import add_indicators, detect_trend

logging.basicConfig(level=logging.INFO)

def send_discord_log(message: str):
    """Trimite log pe Discord prin webhook."""
    webhook = Config.DISCORD_WEBHOOK_URL
    if not webhook:
        return
    try:
        requests.post(webhook, json={"content": f"```{message}```"}, timeout=5)
    except Exception:
        pass

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("GET SIGNAL", callback_data="signal")],
        [InlineKeyboardButton("ANALYZE MARKET", callback_data="analyze")],
        [InlineKeyboardButton("MARKET TREND", callback_data="trend")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "XAUUSD AI Assistant\nAlege o opțiune:",
        reply_markup=reply_markup
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "signal":
        df = get_xauusd_data()
        if df is None:
            await query.edit_message_text("Eroare la preluarea datelor.")
            return
        signal = generate_signal(df)
        
        text = (
            f"SYMBOL: {signal['symbol']}\n"
            f"DIRECTION: {signal['direction']}\n"
            f"ENTRY: {signal['entry']}\n"
            f"STOP LOSS: {signal['stop_loss']}\n"
            f"TAKE PROFIT: {signal['take_profit']}\n"
            f"R/R: {signal['risk_reward']}\n"
            f"CONFIDENCE: {signal['confidence']}%\n"
            f"STRATEGY: {signal['strategy']}\n"
            f"REASON: {signal['reasoning']}\n"
            f"STATUS: {signal['status']}"
        )
        
        await query.edit_message_text(text)
        send_discord_log(f"Semnal: {signal['direction']} @ {signal['entry']}")
    
    elif query.data == "analyze":
        df = get_xauusd_data()
        if df is None:
            await query.edit_message_text("Eroare la preluarea datelor.")
            return
        
        df = add_indicators(df)
        last = df.iloc[-1]
        trend = detect_trend(df)
        
        text = (
            f"=== ANALIZĂ XAUUSD (H1) ===\n"
            f"Preț curent: {last['Close']:.2f}\n"
            f"Trend: {trend}\n"
            f"SMA 20: {last['SMA_20']:.2f}\n"
            f"SMA 50: {last['SMA_50']:.2f}\n"
            f"RSI: {last['RSI']:.1f}\n"
            f"MACD: {last['MACD']:.2f}\n"
            f"ATR: {last['ATR']:.2f}\n\n"
            f"Observații:\n"
            f"- RSI {'supra-cumpărat' if last['RSI'] > 70 else 'supra-vândut' if last['RSI'] < 30 else 'neutru'}\n"
            f"- Volatilitate (ATR): {'ridicată' if last['ATR'] > 15 else 'normală'}"
        )
        await query.edit_message_text(text)
        send_discord_log("Analiză detaliată solicitată")
    
    elif query.data == "trend":
        df = get_xauusd_data()
        if df is None:
            await query.edit_message_text("Eroare la preluarea datelor.")
            return
        df = add_indicators(df)
        trend = detect_trend(df)
        await query.edit_message_text(f"Trend actual XAUUSD: {trend}")
        send_discord_log(f"Trend verificat: {trend}")

def main():
    if not Config.TELEGRAM_BOT_TOKEN:
        print("Lipsește TELEGRAM_BOT_TOKEN în .env")
        return
    
    app = Application.builder().token(Config.TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    print("Bot Telegram pornit...")
    send_discord_log("Telegram bot pornit")
    app.run_polling()

if __name__ == "__main__":
    main()